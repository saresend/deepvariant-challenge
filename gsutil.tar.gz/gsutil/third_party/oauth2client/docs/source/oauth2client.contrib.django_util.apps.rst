oauth2client\.contrib\.django\_util\.apps module
================================================

.. automodule:: oauth2client.contrib.django_util.apps
    :members:
    :undoc-members:
    :show-inheritance:
